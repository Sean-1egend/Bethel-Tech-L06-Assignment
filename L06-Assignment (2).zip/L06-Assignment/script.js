let baseURL = "https://api.sunrise-sunset.org/json?";
let myLatitude = 36.72;
let myLongitude = -4.42;

let myURL = baseURL + "lat=" + myLatitude + "&lng=" + myLongitude + "&date=today";

var btn = document.getElementById('btn');
let myRequest = new XMLHttpRequest();


console.log(myURL)

btn.addEventListener('click', function(event){
    myLatitude = document.getElementById("myLatitude").value;
    myLongitude = document.getElementById("myLongitude").value;
    console.log(myLongitude);
    console.log(myLatitude);
    myURL = baseURL + "lat=" + myLatitude + "&lng=" + myLongitude + "&date=today";
    console.log(myURL);
    myRequest.open('GET', myURL, true);
    myRequest.send();
    myRequest.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                let times = JSON.parse(this.responseText);
                let header = document.createElement('h3');
                let sunrise = document.createElement('p');
                let sunset = document.createElement('p');

                let outCome = document.getElementById('result');

                console.log(times);

                header.innerHTML = "Sunrise and Sunset Times";
                sunrise.innerHTML = "Sunrise= " + times.results.sunrise;
                sunset.innerHTML =  "Sunset= " + times.results.sunset;

                outCome.appendChild(header);
                outCome.appendChild(sunrise);
                outCome.appendChild(sunset);

            } else {
                console.log("Error processing REquest");
            }
        }
    }
});